package org.example;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class CalculadoraController {

    @FXML
    private TextField pantalla;

    private double num1 = 0;
    private String operador = "";
    private boolean nuevaOperacion = true;
    private CalculadoraLogica logica = new CalculadoraLogica();

    @FXML
    void procesarClick(ActionEvent event) {
        Button boton = (Button) event.getSource();
        String valor = boton.getText();

        if (valor.matches("[0-9]")) {
            if (nuevaOperacion || pantalla.getText().equals("0")) {
                pantalla.setText(valor);
                nuevaOperacion = false;
            } else {
                pantalla.setText(pantalla.getText() + valor);
            }
        } else if (valor.equals("C")) {
            pantalla.setText("0");
            num1 = 0;
            operador = "";
            nuevaOperacion = true;
        } else if (valor.equals("=")) {
            if (!operador.isEmpty()) {
                double num2 = Double.parseDouble(pantalla.getText());
                try {
                    switch (operador) {
                        case "+":
                            pantalla.setText(String.valueOf(logica.sumar(num1, num2)));
                            break;
                        case "-":
                            pantalla.setText(String.valueOf(logica.restar(num1, num2)));
                            break;
                        case "*":
                            pantalla.setText(String.valueOf(logica.multiplicar(num1, num2)));
                            break;
                        case "/":
                            pantalla.setText(String.valueOf(logica.dividir(num1, num2)));
                            break;
                    }
                } catch (IllegalArgumentException e) {
                    pantalla.setText("Error");
                }
                operador = "";
                nuevaOperacion = true;
            }
        } else {
            operador = valor;
            num1 = Double.parseDouble(pantalla.getText());
            nuevaOperacion = true;
        }
    }
}